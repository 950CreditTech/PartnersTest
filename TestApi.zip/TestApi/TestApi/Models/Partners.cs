﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestApi.Models
{
    public class Partners
    {


        public string firstName { get; set; }

        public string lastName { get; set; }
        public string Status { get; set; }
        public int EnrollDate { get; set; }

        public string landLordContact { get; set; }
        public string missingDocs { get; set; }
        public int totalEnrollments { get; set; }
        public int totalActiveTenants { get; set; }
        public int totalPending { get; set; }
        public int collectionAccounts { get; set; }
        public int closedAccounts { get; set; }
        public int inactiveAccounts { get; set; }
        public int cancelled { get; set; }
    }
}
