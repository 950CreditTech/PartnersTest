﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestApi.Models
{
    public class LandLord
    {

        public string SP_Internal_ID { get; set; }

        public string CRB_ID { get; set; }

        public string Company_Name { get; set; }

        public string Company_Type { get; set; }

        public string Contact_FirstName { get; set; }

        public string Contact_LastName { get; set; }

        public string Street { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string ZipCode { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string Website { get; set; }

        public bool Use_CRB_Portal { get; set; }

        public List<LandLord> landLordList { get; set; }
    }
}
